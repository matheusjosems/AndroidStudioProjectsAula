import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button loginButton = findViewById(R.id.login_button);
        Button closePopup = findViewById(R.id.close_popup);
        View errorOverlay = findViewById(R.id.error_overlay);
        View errorPopup = findViewById(R.id.error_popup);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText usernameEditText = findViewById(R.id.username);
                EditText passwordEditText = findViewById(R.id.password);

                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (!username.equals("admin") || !password.equals("1234")) {
                    errorOverlay.setVisibility(View.VISIBLE);
                    errorPopup.setVisibility(View.VISIBLE);
                    errorOverlay.bringToFront();
                    errorPopup.bringToFront();
                }
            }
        });

        closePopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errorOverlay.setVisibility(View.GONE);
                errorPopup.setVisibility(View.GONE);
            }
        });
    }
}