package br.uniceub.pdm.intents;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MenuPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        Button btn_te1a1 = findViewById(R.id.btn_abrir_te1a1);
        Button btn_sair = findViewById(R.id.btn_sair_do_app);

        btn_te1a1.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MenuPrincipalActivity.this,
                    ExemplosIntentsImplicitasActivity.class
            );
            startActivity(intent);
        });

        btn_sair.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MenuPrincipalActivity.this,
                    LoginActivity.class
            );
            startActivity(intent);
            finish();
        });
    }
}